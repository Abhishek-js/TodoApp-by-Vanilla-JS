const todoButton = document.querySelector(".todo-button");
const todoinput = document.querySelector(".todo-input");
const todolist = document.querySelector(".todo-list");
const filterOption = document.querySelector(".filter-todo");

todoButton.addEventListener('click',addTodo);
todolist.addEventListener('click',deleteCheck);
filterOption.addEventListener('click',filterTodos);

function addTodo(event){
    // Prevent form from submiting
    event.preventDefault();
    // Add todo Div
    const todoDiv = document.createElement('div');
    todoDiv.classList.add('todo');
    // creat Li
    const newTodo = document.createElement('li');
    newTodo.innerText = todoinput.value;
    newTodo.classList.add('todo-item');
    todoDiv.appendChild(newTodo);
    // check mark button
    const completeButton = document.createElement('button');
    completeButton.innerHTML = '<li class="fas fa-check"></li>';
    completeButton.classList.add('complete-btn');
    todoDiv.appendChild(completeButton)
    // delete button
    const deleteButton = document.createElement('button');
    deleteButton.innerHTML = '<li class="fas fa-trash"></li>';
    deleteButton.classList.add('delete-btn');
    todoDiv.appendChild(deleteButton);
    //append to list
    todolist.appendChild(todoDiv)
    //clear todoInput Value
    todoinput.value = "";
}

function deleteCheck(e){
    const item = e.target;
    //delete todo
    if(item.classList[0] === "delete-btn"){
        const todo = item.parentElement;
        todo.classList.add('fall')
        todo.addEventListener('transitionend', function(){
             todo.remove();
        })
    }
    if(item.classList[0] === "complete-btn"){
        const todo = item.parentElement;
        todo.classList.toggle("completed");
    }
}

function filterTodos(e){
    const todos = todolist.childNodes;
    todos.forEach(function(todo){
        switch(e.target.value){
            case "all":
                todo.style.display = "flex";
                break;
            case "completed":
                if(todo.classList.contains('completed')){
                    todo.style.display = 'flex';
                } else {
                    todo.style.display = 'none';
                }
                break;
           case "uncompleted":
               if(!todo.classList.contains('completed')){
                   todo.style.display = 'flex';
               } else {
                   todo.style.display = 'none';
               }
               break;
            }
    });
}

//save todo list values/data
